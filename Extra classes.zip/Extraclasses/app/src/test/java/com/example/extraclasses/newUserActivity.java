package com.example.extraclasses;

public class newUserActivity {
}
