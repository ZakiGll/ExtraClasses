package com.example.extraclasses;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class DetailedFavoriteCourse extends AppCompatActivity {
    TextView name;
    TextView year;
    TextView price;
    TextView module;
    TextView desc;
    TextView date;
    TextView time;
    TextView adrs;
    String uid;
    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_favorite_course);
        String Cyear = getIntent().getStringExtra("Cyear");
        String Cname = getIntent().getStringExtra("Cname");
        String Cprice = getIntent().getStringExtra("Cprice");
        String Cmodule = getIntent().getStringExtra("Cmodule");
        String Cdisc = getIntent().getStringExtra("Cdisc");
        String Cdate = getIntent().getStringExtra("Cdate");
        String Ctime = getIntent().getStringExtra("Ctime");
        String Cadrs = getIntent().getStringExtra("Cadrs");

        name = findViewById(R.id.DClassNameF);
        module = findViewById(R.id.DclassModuleF);
        year = findViewById(R.id.DclassYearF);
        price = findViewById(R.id.DCourcePriceF);
        desc = findViewById(R.id.DclassDescriptionF);
        date = findViewById(R.id.DclassDateF);
        time = findViewById(R.id.DclassTimeF);
        adrs = findViewById(R.id.DclassAdrsF);


        name.setText(Cname);
        year.setText(Cyear);
        price.setText(Cprice);
        module.setText(Cmodule);
        desc.setText(Cdisc);
        date.setText(Cdate);
        time.setText(Ctime);
        adrs.setText(Cadrs);
    }
}