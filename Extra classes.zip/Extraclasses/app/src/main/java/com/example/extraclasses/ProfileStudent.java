package com.example.extraclasses;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ProfileStudent extends AppCompatActivity {
    String uid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_student);
        TextView nameP = findViewById(R.id.nameProfileS);
        TextView emailP = findViewById(R.id.emailProfileS);
        //TextView ageP = findViewById(R.id.yearProfileStudent);
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        uid=user.getUid().toString();
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://extra-classes-e11d1-default-rtdb.firebaseio.com/Users");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String emailD = snapshot.child(uid).child("email").getValue().toString();
                String nameD = snapshot.child(uid).child("name").getValue().toString();
                //String ageD = snapshot.child(uid).child("age").getValue().toString();
                nameP.setText(nameD);
                emailP.setText(emailD);
//

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {


            }
        });
    }
}