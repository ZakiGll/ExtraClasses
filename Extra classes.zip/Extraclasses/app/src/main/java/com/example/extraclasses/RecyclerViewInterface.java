package com.example.extraclasses;

public interface RecyclerViewInterface {
    void onClickItem(int position);

}
