package com.example.extraclasses;

public class StudentNameForList {
    String StudentName;


    public StudentNameForList(String studentName) {
        this.StudentName = studentName;
    }

    public String getStudentName() {
        return StudentName;
    }

    public void setStudentName(String studentName) {
       this.StudentName = studentName;
    }
    public StudentNameForList(){}
}
