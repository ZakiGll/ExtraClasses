package com.example.extraclasses;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ViewUtils;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ProfileTeacher extends AppCompatActivity {
    String uid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_teacher);
        TextView nameP = findViewById(R.id.nameProfileT);
        TextView emailP = findViewById(R.id.emailProfileT);
        //TextView ageP = findViewById(R.id.yearProfileStudent);
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        uid=user.getUid().toString();
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://extra-classes-e11d1-default-rtdb.firebaseio.com/Users");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String emailD = snapshot.child(uid).child("email").getValue().toString();
                String nameD = snapshot.child(uid).child("name").getValue().toString();
                //String ageD = snapshot.child(uid).child("age").getValue().toString();
                nameP.setText(nameD);
                emailP.setText(emailD);
//

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {


            }
        });

        LinearLayout add = findViewById(R.id.addBtnProfile);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),AddCourse.class);
                startActivity(i);
            }
        });
        LinearLayout home = findViewById(R.id.HomeBtnProfileT);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),HomeTeacher.class);
                startActivity(intent);
            }
        });





    }




}